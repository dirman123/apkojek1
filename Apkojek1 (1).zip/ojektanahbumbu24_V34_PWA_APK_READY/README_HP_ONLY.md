# Ojek Tanah Bumbu V34 — Android Wrapper (HP Only)

Ini adalah project Android wrapper untuk aplikasi online:

https://ojekangsana.pages.dev/

## Tujuan
APK hanya menjadi wadah Android. Mesin utama tetap website Cloudflare.
Karena itu perubahan tampilan/fitur web yang Anda upload ke Cloudflare akan ikut muncul di APK tanpa harus membuat APK baru, selama perubahan tidak membutuhkan izin/native Android baru.

## Yang sudah disiapkan
- WebView fullscreen tanpa address bar.
- JavaScript dan DOM storage aktif.
- GPS/geolocation dengan izin Android.
- Kamera dan mikrofon untuk verifikasi web.
- File chooser/upload untuk KTP/foto/dokumen.
- Tombol Back Android mengikuti histori aplikasi.
- WhatsApp dan Google Maps dibuka ke aplikasi terkait.
- Halaman error koneksi + tombol coba lagi.
- Warna Android ungu.
- Package ID permanen: `com.ojekangsana.app`.
- Workflow GitHub Actions untuk membuat `app-debug.apk` tanpa laptop.

## PENTING
JANGAN upload ZIP project Android ini ke Cloudflare Pages. Ini bukan ZIP website V33/V34.
Project ini khusus untuk membungkus website yang sudah online.

## Upgrade berikutnya
Jika Anda mengubah fitur/tampilan di Cloudflare, APK ini tetap mengarah ke URL yang sama dan akan mengambil aplikasi web terbaru.
APK baru hanya dibutuhkan jika nanti kita menambah fungsi native Android atau permission baru.

## Build dari HP
Folder `.github/workflows/build-apk.yml` sudah disiapkan. Setelah project dimasukkan ke repository GitHub, GitHub Actions dapat membangun APK di server. APK hasil build akan muncul sebagai Artifact bernama `Ojek-Tanah-Bumbu-V34-APK`.

Untuk rilis Play Store nanti, jangan gunakan debug APK. Kita akan membuat signing/keystore release terpisah dan harus disimpan permanen.
