# Intentionally minimal. The wrapper contains no JavaScript bridge.
