# OJEK TANAH BUMBU V34 — ANDROID WRAPPER / APK READY

## Basis
Acuan versi sebelumnya: V33 `MAXIM-LIKE INSTANT LOCATION SEARCH`.
Website live yang dibungkus: `https://ojekangsana.pages.dev/`

## Arsitektur V34
- Cloudflare tetap menjadi mesin utama aplikasi.
- Android APK hanya menjadi wrapper WebView.
- Package Android permanen: `com.ojekangsana.app`.
- Mayoritas update web cukup dilakukan di Cloudflare dan akan tampil di APK lama.
- APK perlu dibuat ulang hanya jika ada perubahan native/permission Android.

## Fitur wrapper Android
- JavaScript + DOM storage.
- GPS/geolocation + runtime permission.
- Kamera dan mikrofon untuk fitur web.
- Upload file/foto untuk KTP/selfie/dokumen.
- Link WhatsApp dan Google Maps dibuka ke app terkait.
- Tombol Back Android mengikuti history WebView.
- Panel koneksi terputus + Retry.
- Tema ungu.
- Workflow GitHub Actions untuk build `app-debug.apk` tanpa laptop.

## Fitur V33 yang menjadi acuan dan tidak boleh sengaja dihilangkan dari aplikasi web
GPS/peta, Google Maps, live driver tracking, rating & ulasan, notifikasi bunyi/getar, layanan Ojek/Barang/Titip/Makanan, driver favorit, anti-fraud, KTP+selfie+liveness, dashboard Driver, dashboard Owner, upload ZIP owner, Undo Pengaturan, Undo Sistem, multi-bahasa.

## Catatan penting
File ini **bukan source web V33**. V34 wrapper membuka deployment web yang sudah online. Jangan upload ZIP Android ke Cloudflare Pages.
