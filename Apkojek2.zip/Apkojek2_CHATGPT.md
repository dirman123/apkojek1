# APKOJEK2 — PERMANENT ANDROID WRAPPER

URL utama: `https://ojekangsana.pages.dev/`
Package: `com.ojekangsana.app`
versionCode: `200`
versionName: `2.0.0`

## Arsitektur
Cloudflare adalah aplikasi utama. APK hanya wrapper Android permanen.
Mayoritas upgrade web cukup upload ZIP baru ke Cloudflare dan APK lama akan membaca versi terbaru.

## Fitur wrapper
GPS/geolocation, kamera, mikrofon, upload KTP/file, external WhatsApp/Google Maps/browser, offline panel, tombol Keluar, double-back exit, purple splash, no-cache WebView/service worker.

## Signing
Apkojek2 harus dibuild sebagai release signed menggunakan 4 GitHub Actions Secrets:
- `ANDROID_KEYSTORE_B64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Nilai secret disimpan di file terpisah `Apkojek2_SIGNING_SECRETS.txt` dan tidak boleh dibagikan/ditaruh di repository public.

Apkojek1 lama adalah debug; uninstall satu kali mungkin diperlukan saat pindah ke Apkojek2. Setelah Apkojek2, gunakan key yang sama untuk semua upgrade native.
