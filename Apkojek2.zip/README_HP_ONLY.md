# APKOJEK2 — BASE ANDROID PERMANEN

Apkojek2 adalah wrapper Android permanen untuk:
`https://ojekangsana.pages.dev/`

## Tujuan utama
Setelah Apkojek2 terpasang, mayoritas perubahan aplikasi dilakukan di Cloudflare saja.
Contoh yang cukup diubah lewat ZIP Cloudflare: tampilan, warna, menu, tarif, pencarian alamat, dashboard, layanan baru, teks, tombol, dan logika web.

APK baru hanya diperlukan jika mengubah bagian Android native seperti launcher icon, nama aplikasi Android, permission Android, package, atau native wrapper.

## Perubahan Apkojek2
- package tetap `com.ojekangsana.app`
- versionCode `200`
- versionName `2.0.0`
- mode no-cache agar update Cloudflare cepat terlihat
- service-worker WebView juga disetel no-cache
- tombol Keluar kecil di kanan atas
- gesture Back: tekan dua kali untuk keluar dari halaman utama
- GPS, kamera, mikrofon, upload file/KTP dipertahankan
- link di luar domain Ojek dibuka ke aplikasi/browser luar
- splash screen ungu
- launcher icon ungu + aksen kuning
- build release memakai signing key permanen lewat GitHub Actions Secrets

## PENTING soal Apkojek1
Apkojek1 sebelumnya adalah debug. Untuk pindah ke signing permanen Apkojek2, kemungkinan perlu uninstall Apkojek1 satu kali, lalu install Apkojek2 release.
Setelah Apkojek2, Apkojek3/4/dst harus memakai signing key yang sama agar bisa update tanpa uninstall.

## Jangan masukkan signing secret ke repository
Gunakan file `Apkojek2_SIGNING_SECRETS.txt` yang diberikan terpisah. Buat 4 GitHub Actions Secrets sesuai nama di file itu.
Jangan bagikan isi file tersebut.
